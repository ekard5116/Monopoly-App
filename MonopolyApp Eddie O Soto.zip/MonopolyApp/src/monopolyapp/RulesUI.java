/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.Document;

/**
 *
 * @author el3me
 */
class RulesUI extends JFrame{
    
    JTextArea rulesDisplay;
    JScrollPane rulesScrollPane;
    JButton backButton, nextButton;
    JPanel rulesPanel, buttonPanel;
    
    private final MonopolyCntl monopolyCntl;
    
    public RulesUI(MonopolyCntl monopolyCntl){
        this.monopolyCntl = monopolyCntl;
        
    }
    public void rulesScreen(boolean tf){
        this.setTitle("Monopoly - Rules");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(850, 700);
        this.setLocationRelativeTo(null);
        
        rulesDisplay = new JTextArea(30, 70);
        rulesDisplay.setText(monopolyCntl.getRules().toString());
        rulesDisplay.setEditable(false);
                
        
        rulesPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        rulesPanel.add(rulesScrollPane = new JScrollPane(rulesDisplay));
        rulesPanel.setVisible(tf);
        
        rulesScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backButton = new JButton("Back"));
        buttonPanel.add(nextButton = new JButton("Next"));
        buttonPanel.setVisible(tf);
        
        backButton.addActionListener(event -> monopolyCntl.toStartScreen());
        nextButton.addActionListener(event -> monopolyCntl.toStartPlayers());
        
        this.setContentPane(new JPanel(new BorderLayout()));
        this.getContentPane().add(rulesPanel, BorderLayout.CENTER);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.setVisible(tf);
        
        
        
    }
    
}
