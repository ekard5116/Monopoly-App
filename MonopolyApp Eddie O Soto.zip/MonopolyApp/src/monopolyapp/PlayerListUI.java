/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 *
 * @author el3me
 */
public class PlayerListUI extends JFrame {
    JPanel listPanel, buttonPanel;
    JLabel playerCount;
    JLabel[] playerLbls;
    JButton backToRules, addPlayer, play;
    int counter;
    
    private final MonopolyCntl monopolyCntl;
    private final GameCntl gameCntl;
    
    public PlayerListUI(MonopolyCntl monopolyCntl, GameCntl gameCntl){
        this.monopolyCntl = monopolyCntl;
        this.gameCntl = gameCntl;
        playerLbls = new JLabel[7];
        counter = 0;
    }
    
    public void playerList(boolean tf){
        this.setTitle("Monopoly - Options");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(350, 550);
        this.setLocationRelativeTo(null);
        
        listPanel = new JPanel(new GridLayout(7,1));
        listPanel.add(playerCount = new JLabel("Players: " + counter + ""));
        for(int i = 0; i < counter; i++){
        listPanel.add(playerLbls[i] = new JLabel(monopolyCntl.players.get(i).userName));
        playerLbls[i].setHorizontalAlignment(JLabel.CENTER);
        }       
        listPanel.setVisible(tf);
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backToRules = new JButton("Back"));
        buttonPanel.add(addPlayer = new JButton("Add Player"));
        buttonPanel.add(play = new JButton("Play"));
        buttonPanel.setVisible(tf);
                
        backToRules.addActionListener(event -> monopolyCntl.toRulesScreen());
        addPlayer.addActionListener(event -> monopolyCntl.toAddPlayer());
        play.addActionListener(event -> System.out.println("You Pressed Play"));
          
        this.setContentPane(new JPanel(new BorderLayout()));
        this.getContentPane().add(listPanel, BorderLayout.CENTER);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.setVisible(tf);
    }
}
