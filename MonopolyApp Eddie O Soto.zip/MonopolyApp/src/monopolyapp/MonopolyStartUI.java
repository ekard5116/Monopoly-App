/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author el3me
 */
class MonopolyStartUI extends JFrame{
    
    JLabel label;
    JButton startButton;
    JPanel buttonPanel;
    InitialPanel initialPanel;
    private final MonopolyCntl monopolyCntl;
    
    public MonopolyStartUI(MonopolyCntl monopolyCntl){
        this.monopolyCntl = monopolyCntl;
    }
    
    public void startScreen(boolean tf){
        this.setTitle("Monopoly");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(650, 600);
        this.setLocationRelativeTo(null);
        
        initialPanel = new InitialPanel();
        initialPanel.setVisible(tf);
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(startButton = new JButton("Start"));
        buttonPanel.setVisible(tf);
        
        startButton.addActionListener(event -> monopolyCntl.toRulesScreen());
        
        this.setContentPane(new JPanel(new BorderLayout()));
        this.getContentPane().add(initialPanel, BorderLayout.CENTER);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.setVisible(tf);
       
    }
    
    
    public class InitialPanel extends JPanel{
        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            Image startImage = Toolkit.getDefaultToolkit().getImage("Images/Monopoly.png"); 
            int newImageWidth = (startImage.getWidth(null)/2);
            int newImageHeight  = (startImage.getHeight(null)/2);
            Graphics2D g2d = (Graphics2D) g;
            int x = (this.getWidth() - newImageWidth) / 2;
            int y = (this.getHeight() - newImageHeight) / 2;
            g2d.drawImage(startImage, x, y, newImageWidth, newImageHeight, this);
            repaint();
        }
    }
}

