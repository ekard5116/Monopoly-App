/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author el3me
 */
public class GameUI extends JFrame{
    
    GamePanel gamePanel;
    
    private final GameCntl gameCntl;
    
    public GameUI(GameCntl gameCntl){
        this.gameCntl = gameCntl;
    }

    void gameScreen(boolean tf) { 
        this.setTitle("Monopoly");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(650, 600);
        this.setLocationRelativeTo(null);
        
        gamePanel = new GamePanel();
        gamePanel.setVisible(tf);
        
        this.setContentPane(new JPanel(new BorderLayout()));
        this.getContentPane().add(gamePanel, BorderLayout.CENTER);
        this.setVisible(tf);
    }
    
    public class GamePanel extends JPanel{
        protected void paintComponent(Graphics g, String welcome, Font font){
            super.paintComponent(g);
            welcome = "Welcome";
            g.setFont(font);
            g.drawString(welcome, 325, 300);
            repaint();
        }
    }
}
