/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.util.ArrayList;

/**
 *
 * @author el3me
 */
public class Options {
    
    String car, thimble, shoe, dog, tophat, battleship, wheelbarrow;
    ArrayList<Icon> icons;
    
    public Options(){
    icons = new ArrayList<>();
    instantiateIcons();
    }
    
    public final void instantiateIcons(){
       icons.add(new Icon("car", "Images/monopoly car.png"));
       icons.add(new Icon("thimble", "Images/monopoly thimble.png"));
       icons.add(new Icon("shoe", "Images/monopoly shoe.png"));
       icons.add(new Icon("tophat", "Images/monopoly tophat.png"));
       icons.add(new Icon("dog", "Images/monopoly dog.png"));
       icons.add(new Icon("battleship", "Images/monopoly battleship.png"));
       icons.add(new Icon("wheelbarrow", "Images/monopoly wheelbarrow.png"));
    }
    
}
