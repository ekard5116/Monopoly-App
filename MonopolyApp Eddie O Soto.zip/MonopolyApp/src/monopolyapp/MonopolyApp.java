/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

/**
 *
 * @author el3me
 */
public class MonopolyApp {

    static MonopolyCntl monopolyCntl;
    static GameCntl gameCntl;
    
    public static void main(String[] args) {
        monopolyCntl = new MonopolyCntl(gameCntl);
        gameCntl = new GameCntl(monopolyCntl);
    }
    
}
