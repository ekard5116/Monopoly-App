/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.util.ArrayList;

/**
 *
 * @author el3me
 */
public class Properties extends ArrayList{
    
    String propertyName;
    int houses, hotels;
    
    public Properties(String propertyName, int houses, int hotels){
        this.propertyName = propertyName;
        this.houses = houses;
        this.hotels = hotels;
    }
    
}
