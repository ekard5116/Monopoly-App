/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author el3me
 */
public class PlayersUI extends JFrame{

    JPanel playerPanel, buttonPanel;
    JLabel playerNameLBL, iconLBL;
    JButton backToList, next;
    JTextField playerName;
    JComboBox<String> icon;
    
    private final MonopolyCntl monopolyCntl;
    
    public PlayersUI(MonopolyCntl monopolyCntl){
        this.monopolyCntl = monopolyCntl;
    }
    public void addPlayer(boolean tf) {
        this.setTitle("Monopoly - Options");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(300,250);
        this.setLocationRelativeTo(null);
        
        playerPanel = new JPanel(new GridLayout(3, 2));
        playerPanel.add(playerNameLBL = new JLabel("Player Name"));
        playerPanel.add(playerName = new JTextField(""));
        playerPanel.add(iconLBL = new JLabel("Icon"));
        playerPanel.add(icon = new JComboBox<>(monopolyCntl.getIcons()));
        playerPanel.setVisible(tf);
        
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backToList = new JButton("Back"));
        buttonPanel.add(next = new JButton("Next"));
        buttonPanel.setVisible(tf);
                       
        backToList.addActionListener(event -> monopolyCntl.backToPlayerList());
        next.addActionListener(event -> monopolyCntl.toPlayerList());
        
        this.setContentPane(new JPanel(new BorderLayout()));
        this.getContentPane().add(playerPanel, BorderLayout.CENTER);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.setVisible(tf);
        
        
    }
}
