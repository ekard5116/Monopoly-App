/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.util.ArrayList;

/**
 *
 * @author el3me
 */
public class Icon {
    
    String name, file;
    
    public Icon(String name, String file){
        this.name = name;
        this.file = file;
    }
    
    public static String[] getNames(ArrayList<Icon> icons){
        String[] names = {icons.get(0).name, icons.get(1).name, icons.get(2).name, icons.get(3).name,
            icons.get(4).name, icons.get(5).name, icons.get(6).name};
        return names;
    }
}
