/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.util.ArrayList;

/**
 *
 * @author el3me
 */
public class Player {
    
    String userName, playerIcon;
    ArrayList<String> CommunityChest, Chance;
    Properties properties;
    int money;
    boolean goToJail, bankrupt, winner;
    
    String dUserName, dPlayerIcon;
    int dMoney;
    boolean dGoToJail, dBankrupt, dWinner;
    
    public Player(String userName, String playerIcon, int money, Properties properties, 
            ArrayList<String> CommunityChest, ArrayList<String> Chance, 
            boolean goToJail, boolean bankrupt, boolean winner){
        this.userName = userName;
        this.playerIcon = playerIcon;
        this.money = money;
        this.properties = properties;
        this.CommunityChest = CommunityChest;
        this.Chance = Chance;
        this.goToJail = goToJail;
        this.bankrupt = bankrupt;
        this.winner = winner;
    }
    public static Player startPlayer(){
        return new Player("Player", null, 1500, null, null, null, false, false, false);       
    }
}
