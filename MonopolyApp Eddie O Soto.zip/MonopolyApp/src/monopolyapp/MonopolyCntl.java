/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolyapp;

import java.util.ArrayList;

/**
 *
 * @author el3me
 */
public class MonopolyCntl {
    Options options;
    Rules rules;
    MonopolyStartUI monopolyStartUI;
    RulesUI rulesUI;
    PlayerListUI playerListUI;
    PlayersUI playersUI;
    GameCntl gameCntl;
    ArrayList<Player> players;
    
    public MonopolyCntl(GameCntl gameCntl){
        this.gameCntl = gameCntl;
        players = new ArrayList<>();
        options = new Options();
        rules = new Rules();
        monopolyStartUI = new MonopolyStartUI(this);
        rulesUI = new RulesUI(this);
        playerListUI = new PlayerListUI(this, gameCntl);
        playersUI = new PlayersUI(this);
        toStartScreen();
    }

    public void toStartScreen() {
        rulesUI.rulesScreen(false);
        monopolyStartUI.startScreen(true);
    }
    
    public void toRulesScreen() {
        playerListUI.counter = 0;
        players.removeAll(players);
        monopolyStartUI.startScreen(false);
        playerListUI.playerList(false);
        rulesUI.rulesScreen(true);
    }

    public String getRules() {
        return rules.getRules();
    }

    public void toStartPlayers() {
        rulesUI.rulesScreen(false);
        playerListUI.playerList(true);
        
    }
    
    public void toAddPlayer() {
        players.add(Player.startPlayer());
        playerListUI.counter += 1;
        playerListUI.playerList(false);
        playersUI.addPlayer(true);
        
    }
    
    public String[] getIcons(){
        return Icon.getNames(options.icons);
    }

    void toPlayerList() {
        System.out.println(playersUI.icon.getSelectedItem()); 
        playersUI.addPlayer(false);
        playerListUI.playerList(true);
             
    }

    void backToPlayerList() {
        if(playerListUI.counter > 0){
            players.remove(players.get(playerListUI.counter - 1));
            playerListUI.counter -= 1;
        }
        playersUI.addPlayer(false);
        playerListUI.playerList(true);
    }    
}
